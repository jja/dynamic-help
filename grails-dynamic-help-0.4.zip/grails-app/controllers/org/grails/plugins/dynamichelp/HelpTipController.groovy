package org.grails.plugins.dynamichelp

class HelpTipController {

   def scaffold = HelpTip

}
